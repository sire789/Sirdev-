import { useState } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Showcase from "./components/Showcase";
import OrderForm from "./components/OrderForm";
import { FAQ, Pricing, Process, TechMarquee, Testimonials, WhyUs } from "./components/Sections";
import { CTA, FloatingWhatsApp, Footer } from "./components/Footer";

const scrollToOrder = () =>
  requestAnimationFrame(() => document.getElementById("order")?.scrollIntoView({ behavior: "smooth" }));

export default function App() {
  const [websiteType, setWebsiteType] = useState("");
  const [pkg, setPkg] = useState("");

  return (
    <div className="min-h-screen overflow-x-hidden bg-ink font-sans">
      <Navbar />
      <main>
        <Hero />
        <TechMarquee />
        <Showcase
          onOrder={(id) => {
            setWebsiteType(id);
            scrollToOrder();
          }}
        />
        <WhyUs />
        <Process />
        <Pricing
          onChoose={(name) => {
            setPkg(name);
            scrollToOrder();
          }}
        />
        <Testimonials />
        <OrderForm websiteType={websiteType} setWebsiteType={setWebsiteType} pkg={pkg} setPkg={setPkg} />
        <FAQ />
        <CTA />
      </main>
      <Footer />
      <FloatingWhatsApp />
    </div>
  );
}
