export const BUSINESS_NAME = "SIRDEV GLOBAL";
export const WHATSAPP_NUMBER = "2348145933485";
export const WHATSAPP_DISPLAY = "+234 814 593 3485";

export const waLink = (message: string) =>
  `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;

export type Category = "Business" | "Commerce" | "Personal" | "Community" | "Apps";

export interface WebsiteType {
  id: string;
  title: string;
  category: Category;
  tagline: string;
  description: string;
  features: string[];
  price: string;
  delivery: string;
  image: string;
  accent: string;
}

const img = (id: string, ext = "jpeg") =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.${ext}?auto=compress&cs=tinysrgb&fit=crop&h=500&w=800`;

export const websiteTypes: WebsiteType[] = [
  {
    id: "ecommerce",
    title: "E-commerce Store",
    category: "Commerce",
    tagline: "Sell online 24/7",
    description:
      "A full online shop with product listings, cart, checkout and payment integration (Paystack, Flutterwave) so you can sell to customers anywhere.",
    features: ["Product & inventory management", "Paystack / Flutterwave payments", "Order tracking & invoices", "Admin dashboard"],
    price: "₦120,000",
    delivery: "2 – 4 weeks",
    image: img("6956903"),
    accent: "from-emerald-400 to-teal-500",
  },
  {
    id: "business",
    title: "Business / Corporate",
    category: "Business",
    tagline: "Look credible, win clients",
    description:
      "A professional company website that showcases your services, team and achievements — built to turn visitors into paying customers.",
    features: ["Services & about pages", "Contact & quote forms", "Google Maps integration", "SEO optimised"],
    price: "₦70,000",
    delivery: "1 – 2 weeks",
    image: img("8190827"),
    accent: "from-sky-400 to-indigo-500",
  },
  {
    id: "portfolio",
    title: "Personal Portfolio",
    category: "Personal",
    tagline: "Show off your best work",
    description:
      "A stunning personal brand website for creatives, freelancers, photographers, artists and professionals to display their work and get hired.",
    features: ["Project gallery", "Résumé / CV section", "Testimonials", "Social media links"],
    price: "₦50,000",
    delivery: "5 – 10 days",
    image: img("7610529"),
    accent: "from-fuchsia-400 to-pink-500",
  },
  {
    id: "restaurant",
    title: "Restaurant & Food",
    category: "Commerce",
    tagline: "Menus that make mouths water",
    description:
      "Beautiful websites for restaurants, cafés, bakeries and caterers with digital menus, table reservations and online food ordering.",
    features: ["Digital menu", "Online ordering", "Table reservation", "WhatsApp order button"],
    price: "₦65,000",
    delivery: "1 – 2 weeks",
    image: img("6327536"),
    accent: "from-orange-400 to-rose-500",
  },
  {
    id: "realestate",
    title: "Real Estate",
    category: "Business",
    tagline: "List properties, close deals",
    description:
      "Property listing websites for realtors and developers with search filters, image galleries, virtual tours and lead capture forms.",
    features: ["Property listings & search", "Photo galleries", "Agent profiles", "Inspection booking"],
    price: "₦100,000",
    delivery: "2 – 3 weeks",
    image: img("8482510"),
    accent: "from-amber-400 to-orange-500",
  },
  {
    id: "school",
    title: "School & Education",
    category: "Community",
    tagline: "Modernise your institution",
    description:
      "Websites for schools, academies and tutors with admission forms, news, events, result checking and e-learning portals.",
    features: ["Online admission", "News & events", "Result checker portal", "Staff & student pages"],
    price: "₦90,000",
    delivery: "2 – 3 weeks",
    image: img("37898351"),
    accent: "from-blue-400 to-cyan-500",
  },
  {
    id: "church",
    title: "Church & NGO",
    category: "Community",
    tagline: "Reach your community",
    description:
      "Inspiring websites for churches, ministries and non-profits featuring sermons, events, live stream, and online giving/donations.",
    features: ["Sermons & media", "Online giving", "Events calendar", "Live stream embed"],
    price: "₦60,000",
    delivery: "1 – 2 weeks",
    image: img("29422232"),
    accent: "from-violet-400 to-purple-500",
  },
  {
    id: "hotel",
    title: "Hotel & Booking",
    category: "Commerce",
    tagline: "Get direct bookings",
    description:
      "Elegant websites for hotels, shortlets, and event centres with room showcases, availability calendars and online booking.",
    features: ["Room showcase", "Booking system", "Online payment", "Reviews & ratings"],
    price: "₦110,000",
    delivery: "2 – 4 weeks",
    image: img("6466496"),
    accent: "from-yellow-400 to-amber-500",
  },
  {
    id: "blog",
    title: "Blog & News",
    category: "Personal",
    tagline: "Share your voice",
    description:
      "Fast, SEO-friendly blogs and news/magazine websites with categories, comments, newsletter sign-up and ad placement spaces.",
    features: ["Easy post editor", "Categories & tags", "Newsletter sign-up", "AdSense ready"],
    price: "₦50,000",
    delivery: "1 – 2 weeks",
    image: img("34601", "jpg"),
    accent: "from-lime-400 to-emerald-500",
  },
  {
    id: "webapp",
    title: "Web App & Dashboard",
    category: "Apps",
    tagline: "Custom software, your way",
    description:
      "Custom web applications — admin dashboards, CRMs, booking platforms, fintech tools and SaaS products tailored to your workflow.",
    features: ["User accounts & login", "Database & APIs", "Analytics dashboard", "Role management"],
    price: "₦200,000",
    delivery: "4 – 8 weeks",
    image: img("10020092"),
    accent: "from-indigo-400 to-blue-600",
  },
  {
    id: "fitness",
    title: "Gym & Fitness",
    category: "Business",
    tagline: "Pump up your memberships",
    description:
      "Energetic websites for gyms, trainers and wellness brands with class schedules, membership plans and trainer bookings.",
    features: ["Class schedules", "Membership plans", "Trainer profiles", "Online sign-up"],
    price: "₦55,000",
    delivery: "1 – 2 weeks",
    image: img("3888405"),
    accent: "from-red-400 to-orange-500",
  },
  {
    id: "landing",
    title: "Landing Page",
    category: "Business",
    tagline: "One page. Maximum conversions",
    description:
      "High-converting single-page websites for product launches, events, ads campaigns, ebooks and lead generation.",
    features: ["Conversion-focused design", "Lead capture form", "WhatsApp CTA", "Fast loading"],
    price: "₦50,000",
    delivery: "3 – 7 days",
    image: img("34577", "jpg"),
    accent: "from-teal-400 to-sky-500",
  },
];

export interface Package {
  name: string;
  price: string;
  note: string;
  popular?: boolean;
  features: string[];
}

export const packages: Package[] = [
  {
    name: "Starter",
    price: "₦50,000",
    note: "Perfect for individuals & small startups",
    features: [
      "1 – 3 pages",
      "Mobile & laptop responsive",
      "WhatsApp chat button",
      "Contact form",
      "Free SSL certificate",
      "1 month free support",
    ],
  },
  {
    name: "Business",
    price: "₦70,000",
    note: "Best for growing businesses",
    popular: true,
    features: [
      "Up to 8 pages",
      "Free domain (.com/.com.ng) for 1 year",
      "Free hosting for 1 year",
      "Business email setup",
      "Basic SEO & Google listing",
      "Social media integration",
      "3 months free support",
    ],
  },
  {
    name: "Premium",
    price: "₦150,000+",
    note: "E-commerce & advanced websites",
    features: [
      "Unlimited pages",
      "E-commerce / booking features",
      "Payment gateway integration",
      "Admin dashboard",
      "Advanced SEO & analytics",
      "Speed & security optimisation",
      "6 months free support",
    ],
  },
];

export const testimonials = [
  {
    name: "Chinedu O.",
    role: "Fashion Store Owner, Lagos",
    text: "SIRDEV GLOBAL built my online store in less than 3 weeks. Sales started coming in from customers outside Lagos almost immediately. Highly recommended!",
  },
  {
    name: "Mrs. Adebayo",
    role: "Proprietress, Bright Stars Academy",
    text: "Our parents now apply for admission and check results online. The website is beautiful and works perfectly on phones. Thank you SIRDEV!",
  },
  {
    name: "Pastor Emeka",
    role: "Grace Assembly",
    text: "Professional, patient and very creative. Our church website now has online giving and sermons. Members love it.",
  },
  {
    name: "Aisha B.",
    role: "Food Vendor, Abuja",
    text: "My restaurant site with WhatsApp ordering doubled my orders. Fast delivery and they explained everything clearly.",
  },
];

export const faqs = [
  {
    q: "How long does it take to build a website?",
    a: "Simple websites and landing pages take 3–10 days. Business websites take 1–2 weeks, while e-commerce and custom web apps can take 2–8 weeks depending on features.",
  },
  {
    q: "Will my website work on mobile phones?",
    a: "Yes! Every website we build is fully responsive — it looks and works great on phones, tablets, laptops and desktops.",
  },
  {
    q: "How do I pay?",
    a: "We usually take 50–70% upfront to begin, and the balance after you review and approve the website. Payment is by bank transfer.",
  },
  {
    q: "Do you provide domain name and hosting?",
    a: "Yes. Our Business and Premium packages include a free domain and hosting for the first year. We can also use your existing domain.",
  },
  {
    q: "Can I update the website myself?",
    a: "Absolutely. We can build with an easy-to-use admin panel and train you on how to add products, posts, or update content yourself.",
  },
  {
    q: "Do you offer support after launch?",
    a: "Yes, every package comes with free support, and we offer affordable maintenance plans afterward to keep your site secure and up to date.",
  },
];
