import { useState } from "react";
import {
  Smartphone,
  Rocket,
  Search,
  ShieldCheck,
  Palette,
  Headphones,
  MessageSquare,
  PenTool,
  Code2,
  Send,
  Check,
  Star,
  Plus,
  Quote,
} from "lucide-react";
import { cn } from "../utils/cn";
import { faqs, packages, testimonials } from "../data";
import { Reveal, SectionHeading } from "./ui";

const tech = ["React", "Next.js", "WordPress", "Shopify", "Tailwind CSS", "Node.js", "Laravel", "Firebase", "Paystack", "Flutterwave", "MongoDB", "Figma"];

export function TechMarquee() {
  return (
    <div className="relative overflow-hidden border-y border-white/5 bg-white/[0.02] py-6">
      <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-20 bg-gradient-to-r from-ink to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-20 bg-gradient-to-l from-ink to-transparent" />
      <div className="animate-marquee flex w-max gap-12">
        {[...tech, ...tech].map((t, i) => (
          <span key={i} className="font-display text-lg font-semibold whitespace-nowrap text-slate-500 sm:text-xl">
            {t}
          </span>
        ))}
      </div>
    </div>
  );
}

const reasons = [
  { icon: Smartphone, title: "Mobile & Laptop Friendly", text: "Every site adapts perfectly to phones, tablets, laptops and desktops." },
  { icon: Rocket, title: "Lightning Fast", text: "Optimised code and images so your pages load in a blink." },
  { icon: Search, title: "SEO Ready", text: "Built so customers can find you on Google from day one." },
  { icon: ShieldCheck, title: "Secure & Reliable", text: "SSL, backups and best-practice security keep you protected." },
  { icon: Palette, title: "Unique Design", text: "No boring templates — custom designs that reflect your brand." },
  { icon: Headphones, title: "Ongoing Support", text: "We're a WhatsApp message away whenever you need help." },
];

export function WhyUs() {
  return (
    <section className="relative py-20 md:py-28">
      <div className="pointer-events-none absolute left-0 top-1/3 h-80 w-80 rounded-full bg-indigo-600/15 blur-[120px]" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Why SIRDEV GLOBAL"
          title={<>Websites that work <span className="text-gradient">as hard as you do</span></>}
          subtitle="We combine great design, clean code and business strategy to deliver results."
        />
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {reasons.map((r, i) => (
            <Reveal key={r.title} delay={(i % 3) * 80}>
              <div className="group h-full rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.04] to-transparent p-6 transition hover:border-emerald-400/30 sm:p-7">
                <span className="grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br from-emerald-400/20 to-indigo-500/20 ring-1 ring-white/10 transition group-hover:scale-110">
                  <r.icon className="h-6 w-6 text-emerald-300" />
                </span>
                <h3 className="mt-5 font-display text-lg font-bold text-white">{r.title}</h3>
                <p className="mt-2 text-sm text-slate-400">{r.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

const steps = [
  { icon: MessageSquare, title: "Chat With Us", text: "Send your order via WhatsApp or the form. Tell us about your business and goals." },
  { icon: PenTool, title: "Design", text: "We create a modern design concept and refine it with your feedback." },
  { icon: Code2, title: "Develop", text: "We build your site with clean, fast and responsive code, then test on all devices." },
  { icon: Send, title: "Launch & Support", text: "Your website goes live! We train you and keep supporting you afterwards." },
];

export function Process() {
  return (
    <section id="process" className="relative border-y border-white/5 bg-white/[0.015] py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="How it works"
          title={<>From idea to live website <span className="text-gradient">in 4 steps</span></>}
        />
        <div className="relative grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <div className="pointer-events-none absolute top-10 left-[12%] right-[12%] hidden h-px bg-gradient-to-r from-emerald-400/0 via-emerald-400/40 to-indigo-500/0 lg:block" />
          {steps.map((s, i) => (
            <Reveal key={s.title} delay={i * 100}>
              <div className="relative h-full rounded-2xl border border-white/10 bg-panel p-6 text-center">
                <span className="relative mx-auto grid h-20 w-20 place-items-center rounded-2xl bg-gradient-to-br from-emerald-400 to-indigo-500 shadow-xl shadow-emerald-500/20">
                  <s.icon className="h-8 w-8 text-white" />
                  <span className="absolute -right-2 -top-2 grid h-7 w-7 place-items-center rounded-full border border-white/20 bg-ink text-xs font-bold text-white">
                    {i + 1}
                  </span>
                </span>
                <h3 className="mt-6 font-display text-lg font-bold text-white">{s.title}</h3>
                <p className="mt-2 text-sm text-slate-400">{s.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Pricing({ onChoose }: { onChoose: (pkg: string) => void }) {
  return (
    <section id="pricing" className="relative py-20 md:py-28">
      <div className="pointer-events-none absolute right-0 top-1/4 h-96 w-96 rounded-full bg-emerald-500/10 blur-[120px]" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Pricing"
          title={<>Simple, <span className="text-gradient">affordable</span> packages</>}
          subtitle="Transparent pricing with no hidden charges. Prices are negotiable based on your exact needs."
        />
        <div className="grid items-stretch gap-6 lg:grid-cols-3">
          {packages.map((p, i) => (
            <Reveal key={p.name} delay={i * 100}>
              <div
                className={cn(
                  "relative flex h-full flex-col rounded-3xl border p-7 sm:p-8",
                  p.popular
                    ? "border-emerald-400/50 bg-gradient-to-b from-emerald-400/10 via-panel to-panel shadow-2xl shadow-emerald-500/10 lg:-translate-y-4"
                    : "border-white/10 bg-panel"
                )}
              >
                {p.popular && (
                  <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-emerald-400 to-teal-500 px-4 py-1 text-xs font-bold text-ink">
                    MOST POPULAR
                  </span>
                )}
                <h3 className="font-display text-xl font-bold text-white">{p.name}</h3>
                <p className="mt-1 text-sm text-slate-400">{p.note}</p>
                <p className="mt-6 font-display text-4xl font-bold text-white sm:text-5xl">{p.price}</p>
                <p className="mt-1 text-xs text-slate-500">one-time payment</p>
                <ul className="mt-7 flex-1 space-y-3">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-3 text-sm text-slate-300">
                      <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-emerald-400/15">
                        <Check className="h-3 w-3 text-emerald-400" />
                      </span>
                      {f}
                    </li>
                  ))}
                </ul>
                <button
                  onClick={() => onChoose(p.name)}
                  className={cn(
                    "mt-8 w-full rounded-xl px-6 py-3.5 font-semibold transition",
                    p.popular
                      ? "bg-gradient-to-r from-emerald-400 to-teal-500 text-ink hover:brightness-110"
                      : "border border-white/15 bg-white/5 text-white hover:bg-white/10"
                  )}
                >
                  Choose {p.name}
                </button>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Testimonials() {
  return (
    <section id="reviews" className="relative border-y border-white/5 bg-white/[0.015] py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Testimonials"
          title={<>Loved by <span className="text-gradient">our clients</span></>}
        />
        <div className="grid gap-6 md:grid-cols-2">
          {testimonials.map((t, i) => (
            <Reveal key={t.name} delay={(i % 2) * 100}>
              <figure className="relative h-full rounded-2xl border border-white/10 bg-panel p-6 sm:p-8">
                <Quote className="absolute right-6 top-6 h-10 w-10 text-white/5" />
                <div className="flex gap-1">
                  {Array.from({ length: 5 }).map((_, k) => (
                    <Star key={k} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <blockquote className="mt-4 text-slate-300">"{t.text}"</blockquote>
                <figcaption className="mt-6 flex items-center gap-3">
                  <span className="grid h-11 w-11 place-items-center rounded-full bg-gradient-to-br from-emerald-400 to-indigo-500 font-bold text-white">
                    {t.name.charAt(0)}
                  </span>
                  <div>
                    <p className="font-semibold text-white">{t.name}</p>
                    <p className="text-xs text-slate-500">{t.role}</p>
                  </div>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="py-20 md:py-28">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <SectionHeading eyebrow="FAQ" title={<>Questions? <span className="text-gradient">Answers.</span></>} />
        <div className="space-y-3">
          {faqs.map((f, i) => {
            const isOpen = open === i;
            return (
              <Reveal key={f.q} delay={i * 50}>
                <div
                  className={cn(
                    "rounded-2xl border bg-panel transition",
                    isOpen ? "border-emerald-400/30" : "border-white/10"
                  )}
                >
                  <button
                    onClick={() => setOpen(isOpen ? null : i)}
                    className="flex w-full items-center justify-between gap-4 p-5 text-left sm:p-6"
                  >
                    <span className="font-semibold text-white">{f.q}</span>
                    <Plus
                      className={cn(
                        "h-5 w-5 shrink-0 text-emerald-400 transition-transform duration-300",
                        isOpen && "rotate-45"
                      )}
                    />
                  </button>
                  <div
                    className={cn(
                      "grid transition-all duration-300",
                      isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                    )}
                  >
                    <div className="overflow-hidden">
                      <p className="px-5 pb-5 text-sm text-slate-400 sm:px-6 sm:pb-6">{f.a}</p>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
