import { ArrowUp } from "lucide-react";
import { waLink, websiteTypes, WHATSAPP_DISPLAY } from "../data";
import { LogoMark, WhatsAppIcon } from "./ui";

export function CTA() {
  return (
    <section className="px-4 pb-20 sm:px-6 lg:px-8">
      <div className="relative mx-auto max-w-6xl overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-500 via-teal-600 to-indigo-700 p-8 text-center sm:p-14">
        <div className="grid-bg pointer-events-none absolute inset-0 opacity-40" />
        <div className="relative">
          <h2 className="font-display text-3xl font-bold text-white sm:text-5xl">Ready to take your business online?</h2>
          <p className="mx-auto mt-4 max-w-xl text-white/85">
            Join businesses across Nigeria and beyond that trust SIRDEV GLOBAL to build their online presence.
          </p>
          <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
            <a href="#order" className="rounded-xl bg-white px-7 py-4 font-semibold text-ink transition hover:bg-white/90">
              Start Your Order
            </a>
            <a
              href={waLink("Hello SIRDEV GLOBAL 👋, I'm ready to get my website built!")}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 rounded-xl border border-white/40 bg-white/10 px-7 py-4 font-semibold text-white backdrop-blur transition hover:bg-white/20"
            >
              <WhatsAppIcon className="h-5 w-5" /> {WHATSAPP_DISPLAY}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-white/10 bg-panel/50">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:grid-cols-2 sm:px-6 lg:grid-cols-4 lg:px-8">
        <div className="lg:col-span-2">
          <a href="#top" className="flex items-center gap-2.5">
            <LogoMark className="h-12 w-12" />
            <span className="font-display text-xl font-bold text-white">
              SIRDEV<span className="text-emerald-400"> GLOBAL</span>
            </span>
          </a>
          <p className="mt-4 max-w-sm text-sm text-slate-400">
            Professional web design & development. We create beautiful, fast and mobile-friendly websites that help
            businesses grow.
          </p>
          <a
            href={waLink("Hello SIRDEV GLOBAL 👋")}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-5 inline-flex items-center gap-2 rounded-xl bg-[#25D366]/10 px-4 py-2.5 text-sm font-semibold text-[#25D366] ring-1 ring-[#25D366]/30 hover:bg-[#25D366]/20"
          >
            <WhatsAppIcon className="h-4 w-4" /> {WHATSAPP_DISPLAY}
          </a>
        </div>
        <div>
          <h4 className="font-display font-semibold text-white">Websites</h4>
          <ul className="mt-4 space-y-2 text-sm text-slate-400">
            {websiteTypes.slice(0, 6).map((w) => (
              <li key={w.id}>
                <a href="#websites" className="hover:text-emerald-300">{w.title}</a>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="font-display font-semibold text-white">Company</h4>
          <ul className="mt-4 space-y-2 text-sm text-slate-400">
            <li><a href="#process" className="hover:text-emerald-300">How it works</a></li>
            <li><a href="#pricing" className="hover:text-emerald-300">Pricing</a></li>
            <li><a href="#reviews" className="hover:text-emerald-300">Reviews</a></li>
            <li><a href="#faq" className="hover:text-emerald-300">FAQ</a></li>
            <li><a href="#order" className="hover:text-emerald-300">Place an order</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/5">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 py-6 text-xs text-slate-500 sm:flex-row sm:px-6 lg:px-8">
          <p>© {new Date().getFullYear()} SIRDEV GLOBAL. All rights reserved.</p>
          <a href="#top" className="flex items-center gap-1 hover:text-white">
            Back to top <ArrowUp className="h-3.5 w-3.5" />
          </a>
        </div>
      </div>
    </footer>
  );
}

export function FloatingWhatsApp() {
  return (
    <a
      href={waLink("Hello SIRDEV GLOBAL 👋, I'd like to order a website.")}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with SIRDEV GLOBAL on WhatsApp"
      className="group fixed bottom-5 right-5 z-40 flex items-center gap-2 sm:bottom-6 sm:right-6"
    >
      <span className="hidden rounded-full bg-white px-4 py-2 text-sm font-semibold text-ink shadow-xl transition group-hover:block md:block">
        Order on WhatsApp
      </span>
      <span className="pulse-ring relative isolate grid h-14 w-14 place-items-center rounded-full bg-[#25D366] text-white shadow-2xl shadow-green-600/40 sm:h-16 sm:w-16">
        <WhatsAppIcon className="h-7 w-7 sm:h-8 sm:w-8" />
      </span>
    </a>
  );
}
