import { ArrowRight, CheckCircle2, Smartphone, Laptop, Zap, ShoppingCart, Star } from "lucide-react";
import { WhatsAppIcon } from "./ui";
import { waLink } from "../data";

const stats = [
  { value: "150+", label: "Websites Delivered" },
  { value: "100%", label: "Mobile Friendly" },
  { value: "24/7", label: "WhatsApp Support" },
  { value: "5★", label: "Client Rating" },
];

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pt-28 pb-16 sm:pt-32 md:pt-40 md:pb-24">
      {/* Background */}
      <div className="grid-bg pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_at_top,black_30%,transparent_75%)]" />
      <div className="pointer-events-none absolute -top-40 left-1/2 h-[500px] w-[800px] -translate-x-1/2 rounded-full bg-emerald-500/20 blur-[120px]" />
      <div className="pointer-events-none absolute top-40 -right-40 h-[400px] w-[400px] rounded-full bg-indigo-600/25 blur-[120px]" />

      <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-4 sm:px-6 lg:grid-cols-2 lg:gap-10 lg:px-8">
        {/* Copy */}
        <div className="text-center lg:text-left">
          <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs font-medium text-slate-300 sm:text-sm">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
            </span>
            Now taking new projects
          </span>

          <h1 className="mt-6 font-display text-4xl font-bold leading-[1.08] tracking-tight text-white sm:text-5xl md:text-6xl xl:text-7xl">
            We build websites that <span className="text-gradient">grow your business.</span>
          </h1>

          <p className="mx-auto mt-6 max-w-xl text-base text-slate-400 sm:text-lg lg:mx-0">
            <strong className="text-white">SIRDEV GLOBAL</strong> designs and develops fast, beautiful and
            mobile-friendly websites — from online stores and business sites to school portals and custom web apps.
          </p>

          <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row sm:justify-center lg:justify-start">
            <a
              href="#order"
              className="group inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-500 px-7 py-4 font-semibold text-ink shadow-xl shadow-emerald-500/25 transition hover:brightness-110 sm:w-auto"
            >
              Order Your Website
              <ArrowRight className="h-5 w-5 transition group-hover:translate-x-1" />
            </a>
            <a
              href="#websites"
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/5 px-7 py-4 font-semibold text-white transition hover:bg-white/10 sm:w-auto"
            >
              See What We Build
            </a>
          </div>

          <ul className="mt-8 flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm text-slate-400 lg:justify-start">
            {["Free consultation", "Fast delivery", "Affordable prices"].map((t) => (
              <li key={t} className="flex items-center gap-1.5">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" /> {t}
              </li>
            ))}
          </ul>
        </div>

        {/* Device mockups */}
        <div className="relative mx-auto w-full max-w-xl">
          {/* Laptop */}
          <div className="animate-floaty">
            <div className="rounded-t-2xl border border-white/10 bg-panel p-2 shadow-2xl shadow-indigo-900/40 sm:p-3">
              <div className="overflow-hidden rounded-lg bg-slate-950">
                <div className="flex items-center gap-1.5 border-b border-white/5 bg-slate-900 px-3 py-2">
                  <span className="h-2.5 w-2.5 rounded-full bg-red-400" />
                  <span className="h-2.5 w-2.5 rounded-full bg-yellow-400" />
                  <span className="h-2.5 w-2.5 rounded-full bg-green-400" />
                  <span className="ml-3 flex-1 truncate rounded-md bg-slate-800 px-3 py-0.5 text-[10px] text-slate-400">
                    https://yourbusiness.com
                  </span>
                </div>
                <div className="relative aspect-[16/10]">
                  <img
                    src="https://images.pexels.com/photos/943096/pexels-photo-943096.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
                    alt="Code on laptop screen"
                    className="absolute inset-0 h-full w-full object-cover opacity-40"
                  />
                  <div className="absolute inset-0 bg-gradient-to-br from-indigo-950/80 via-slate-950/60 to-emerald-950/70" />
                  <div className="relative flex h-full flex-col justify-center p-4 sm:p-8">
                    <div className="h-2 w-16 rounded bg-emerald-400/80" />
                    <div className="mt-3 h-4 w-3/4 rounded bg-white/90 sm:h-5" />
                    <div className="mt-2 h-4 w-1/2 rounded bg-white/70 sm:h-5" />
                    <div className="mt-3 h-2 w-2/3 rounded bg-white/25" />
                    <div className="mt-1.5 h-2 w-1/2 rounded bg-white/25" />
                    <div className="mt-4 flex gap-2">
                      <div className="h-6 w-20 rounded-md bg-gradient-to-r from-emerald-400 to-teal-500 sm:h-7" />
                      <div className="h-6 w-16 rounded-md border border-white/30 sm:h-7" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="mx-auto h-3 w-[110%] -translate-x-[4.5%] rounded-b-2xl bg-gradient-to-b from-slate-600 to-slate-800" />
          </div>

          {/* Phone */}
          <div className="absolute -bottom-8 -right-2 w-[28%] animate-floaty sm:-right-6" style={{ animationDelay: "1.5s" }}>
            <div className="rounded-[1.4rem] border-4 border-slate-700 bg-slate-950 p-1 shadow-2xl shadow-emerald-900/40">
              <div className="overflow-hidden rounded-[1rem] bg-gradient-to-b from-emerald-500/30 to-indigo-600/30">
                <div className="mx-auto mt-1 h-1.5 w-10 rounded-full bg-slate-800" />
                <div className="space-y-1.5 p-2">
                  <div className="aspect-square rounded-lg bg-white/15" />
                  <div className="h-1.5 w-3/4 rounded bg-white/80" />
                  <div className="h-1.5 w-1/2 rounded bg-white/40" />
                  <div className="h-4 rounded-md bg-emerald-400" />
                  <div className="grid grid-cols-2 gap-1">
                    <div className="aspect-square rounded bg-white/10" />
                    <div className="aspect-square rounded bg-white/10" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Floating chips */}
          <div className="absolute -left-2 top-6 hidden items-center gap-2 rounded-xl border border-white/10 bg-panel/90 px-3 py-2 shadow-xl backdrop-blur sm:flex md:-left-8">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-emerald-400/15">
              <ShoppingCart className="h-4 w-4 text-emerald-400" />
            </span>
            <div>
              <p className="text-xs font-semibold text-white">New order!</p>
              <p className="text-[10px] text-slate-400">₦50,000 · just now</p>
            </div>
          </div>
          <div className="absolute -left-4 bottom-2 hidden items-center gap-2 rounded-xl border border-white/10 bg-panel/90 px-3 py-2 shadow-xl backdrop-blur sm:flex">
            <Zap className="h-4 w-4 text-yellow-400" />
            <span className="text-xs font-semibold text-white">99 Speed Score</span>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="relative mx-auto mt-20 max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-white/10 bg-white/10 md:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label} className="bg-ink/90 p-5 text-center sm:p-7">
              <p className="font-display text-2xl font-bold text-white sm:text-4xl">{s.value}</p>
              <p className="mt-1 text-xs text-slate-400 sm:text-sm">{s.label}</p>
            </div>
          ))}
        </div>
        <div className="mt-6 flex flex-wrap items-center justify-center gap-4 text-sm text-slate-400">
          <span className="flex items-center gap-1.5"><Laptop className="h-4 w-4 text-indigo-400" /> Laptop ready</span>
          <span className="flex items-center gap-1.5"><Smartphone className="h-4 w-4 text-emerald-400" /> Mobile ready</span>
          <span className="flex items-center gap-1.5"><Star className="h-4 w-4 text-yellow-400" /> SEO optimised</span>
          <a
            href={waLink("Hello SIRDEV GLOBAL, I'd like to discuss a website project.")}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-[#25D366] hover:underline"
          >
            <WhatsAppIcon className="h-4 w-4" /> Quick chat
          </a>
        </div>
      </div>
    </section>
  );
}
