import { useState, type FormEvent } from "react";
import { Phone, MapPin, Clock, Send, CheckCircle2 } from "lucide-react";
import { cn } from "../utils/cn";
import { packages, waLink, websiteTypes, WHATSAPP_DISPLAY } from "../data";
import { Reveal, SectionHeading, WhatsAppIcon } from "./ui";

const extras = [
  "Domain & Hosting",
  "Logo Design",
  "Business Email",
  "Payment Integration",
  "Admin Dashboard",
  "Blog Section",
  "SEO Setup",
  "Social Media Links",
];

const budgets = ["₦50,000 – ₦100,000", "₦100,000 – ₦200,000", "₦200,000+", "Not sure yet"];
const timelines = ["ASAP (Urgent)", "Within 1 week", "Within 2 weeks", "Within 1 month", "Flexible"];

interface Props {
  websiteType: string;
  setWebsiteType: (v: string) => void;
  pkg: string;
  setPkg: (v: string) => void;
}

const inputCls =
  "w-full rounded-xl border border-white/10 bg-ink/60 px-4 py-3 text-sm text-white placeholder-slate-500 outline-none transition focus:border-emerald-400/60 focus:ring-2 focus:ring-emerald-400/20";

export default function OrderForm({ websiteType, setWebsiteType, pkg, setPkg }: Props) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [business, setBusiness] = useState("");
  const [budget, setBudget] = useState("");
  const [timeline, setTimeline] = useState("");
  const [features, setFeatures] = useState<string[]>([]);
  const [details, setDetails] = useState("");
  const [sent, setSent] = useState(false);

  const toggle = (f: string) =>
    setFeatures((prev) => (prev.includes(f) ? prev.filter((x) => x !== f) : [...prev, f]));

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const typeTitle = websiteTypes.find((w) => w.id === websiteType)?.title ?? "Not specified";
    const lines = [
      "Hello *SIRDEV GLOBAL* 👋",
      "I'd like to place an order for a website.",
      "",
      "*📋 ORDER DETAILS*",
      `• *Name:* ${name}`,
      `• *Phone:* ${phone}`,
      business && `• *Business:* ${business}`,
      `• *Website Type:* ${typeTitle}`,
      pkg && `• *Package:* ${pkg}`,
      budget && `• *Budget:* ${budget}`,
      timeline && `• *Timeline:* ${timeline}`,
      features.length > 0 && `• *Extra Features:* ${features.join(", ")}`,
      details && "",
      details && `*📝 Project Description:*\n${details}`,
      "",
      "Looking forward to hearing from you!",
    ].filter((l) => l !== false && l !== undefined && l !== null) as string[];

    window.open(waLink(lines.join("\n")), "_blank", "noopener,noreferrer");
    setSent(true);
    setTimeout(() => setSent(false), 6000);
  };

  return (
    <section id="order" className="relative overflow-hidden py-20 md:py-28">
      <div className="grid-bg pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_at_center,black_20%,transparent_70%)]" />
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-[500px] w-[700px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-emerald-500/10 blur-[120px]" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="Place your order"
          title={<>Let's build your <span className="text-gradient">website</span></>}
          subtitle="Fill the form below and your order will be sent directly to our WhatsApp. We'll reply within minutes!"
        />

        <div className="grid gap-8 lg:grid-cols-5">
          {/* Contact info */}
          <Reveal className="lg:col-span-2">
            <div className="h-full rounded-3xl border border-white/10 bg-gradient-to-br from-emerald-500/15 via-panel to-indigo-600/15 p-6 sm:p-8">
              <h3 className="font-display text-2xl font-bold text-white">Talk to SIRDEV GLOBAL</h3>
              <p className="mt-2 text-slate-400">
                Prefer to chat directly? Reach us on WhatsApp — we respond fast and offer free consultations.
              </p>

              <ul className="mt-8 space-y-5">
                <li className="flex items-start gap-4">
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[#25D366]/15">
                    <WhatsAppIcon className="h-5 w-5 text-[#25D366]" />
                  </span>
                  <div>
                    <p className="text-xs uppercase tracking-wider text-slate-500">WhatsApp</p>
                    <p className="font-semibold text-white">{WHATSAPP_DISPLAY}</p>
                  </div>
                </li>
                <li className="flex items-start gap-4">
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-white/5">
                    <Phone className="h-5 w-5 text-emerald-300" />
                  </span>
                  <div>
                    <p className="text-xs uppercase tracking-wider text-slate-500">Call</p>
                    <a href="tel:+2348145933485" className="font-semibold text-white hover:text-emerald-300">
                      {WHATSAPP_DISPLAY}
                    </a>
                  </div>
                </li>
                <li className="flex items-start gap-4">
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-white/5">
                    <Clock className="h-5 w-5 text-emerald-300" />
                  </span>
                  <div>
                    <p className="text-xs uppercase tracking-wider text-slate-500">Working hours</p>
                    <p className="font-semibold text-white">Mon – Sat · 8am – 9pm</p>
                  </div>
                </li>
                <li className="flex items-start gap-4">
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-white/5">
                    <MapPin className="h-5 w-5 text-emerald-300" />
                  </span>
                  <div>
                    <p className="text-xs uppercase tracking-wider text-slate-500">Location</p>
                    <p className="font-semibold text-white">Nigeria · Serving clients worldwide</p>
                  </div>
                </li>
              </ul>

              <a
                href={waLink("Hello SIRDEV GLOBAL 👋, I'd like to make an enquiry about building a website.")}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-8 flex w-full items-center justify-center gap-2 rounded-xl bg-[#25D366] px-6 py-4 font-semibold text-white shadow-lg shadow-green-600/20 transition hover:brightness-110"
              >
                <WhatsAppIcon className="h-5 w-5" /> Chat on WhatsApp Now
              </a>
            </div>
          </Reveal>

          {/* Form */}
          <Reveal className="lg:col-span-3" delay={100}>
            <form
              onSubmit={submit}
              className="rounded-3xl border border-white/10 bg-panel/90 p-6 shadow-2xl backdrop-blur sm:p-8"
            >
              <div className="grid gap-5 sm:grid-cols-2">
                <label className="block">
                  <span className="mb-1.5 block text-sm font-medium text-slate-300">Full Name *</span>
                  <input required value={name} onChange={(e) => setName(e.target.value)} placeholder="John Doe" className={inputCls} />
                </label>
                <label className="block">
                  <span className="mb-1.5 block text-sm font-medium text-slate-300">Phone Number *</span>
                  <input
                    required
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="0801 234 5678"
                    className={inputCls}
                  />
                </label>
                <label className="block sm:col-span-2">
                  <span className="mb-1.5 block text-sm font-medium text-slate-300">Business / Brand Name</span>
                  <input value={business} onChange={(e) => setBusiness(e.target.value)} placeholder="e.g. Ada's Kitchen" className={inputCls} />
                </label>
                <label className="block">
                  <span className="mb-1.5 block text-sm font-medium text-slate-300">Website Type *</span>
                  <select required value={websiteType} onChange={(e) => setWebsiteType(e.target.value)} className={inputCls}>
                    <option value="" disabled>Select a website type</option>
                    {websiteTypes.map((w) => (
                      <option key={w.id} value={w.id} className="bg-panel">
                        {w.title} (from {w.price})
                      </option>
                    ))}
                    <option value="custom" className="bg-panel">Other / Custom</option>
                  </select>
                </label>
                <label className="block">
                  <span className="mb-1.5 block text-sm font-medium text-slate-300">Package</span>
                  <select value={pkg} onChange={(e) => setPkg(e.target.value)} className={inputCls}>
                    <option value="">Not sure / Recommend one</option>
                    {packages.map((p) => (
                      <option key={p.name} value={p.name} className="bg-panel">
                        {p.name} — {p.price}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="block">
                  <span className="mb-1.5 block text-sm font-medium text-slate-300">Budget</span>
                  <select value={budget} onChange={(e) => setBudget(e.target.value)} className={inputCls}>
                    <option value="">Select budget</option>
                    {budgets.map((b) => (
                      <option key={b} className="bg-panel">{b}</option>
                    ))}
                  </select>
                </label>
                <label className="block">
                  <span className="mb-1.5 block text-sm font-medium text-slate-300">Timeline</span>
                  <select value={timeline} onChange={(e) => setTimeline(e.target.value)} className={inputCls}>
                    <option value="">Select timeline</option>
                    {timelines.map((t) => (
                      <option key={t} className="bg-panel">{t}</option>
                    ))}
                  </select>
                </label>
              </div>

              <fieldset className="mt-6">
                <legend className="mb-3 text-sm font-medium text-slate-300">Extra features (optional)</legend>
                <div className="flex flex-wrap gap-2">
                  {extras.map((f) => {
                    const on = features.includes(f);
                    return (
                      <button
                        type="button"
                        key={f}
                        onClick={() => toggle(f)}
                        className={cn(
                          "flex items-center gap-1.5 rounded-full border px-3.5 py-2 text-xs font-medium transition sm:text-sm",
                          on
                            ? "border-emerald-400/60 bg-emerald-400/15 text-emerald-200"
                            : "border-white/10 text-slate-400 hover:border-white/25 hover:text-white"
                        )}
                      >
                        {on && <CheckCircle2 className="h-3.5 w-3.5" />}
                        {f}
                      </button>
                    );
                  })}
                </div>
              </fieldset>

              <label className="mt-6 block">
                <span className="mb-1.5 block text-sm font-medium text-slate-300">Tell us about your project</span>
                <textarea
                  rows={4}
                  value={details}
                  onChange={(e) => setDetails(e.target.value)}
                  placeholder="Describe your business, the pages you need, websites you like, colours, etc."
                  className={cn(inputCls, "resize-none")}
                />
              </label>

              <button
                type="submit"
                className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-[#25D366] px-6 py-4 text-base font-semibold text-white shadow-lg shadow-green-600/25 transition hover:brightness-110"
              >
                <WhatsAppIcon className="h-5 w-5" /> Send Order via WhatsApp <Send className="h-4 w-4" />
              </button>

              {sent ? (
                <p className="mt-4 flex items-center justify-center gap-2 rounded-xl bg-emerald-400/10 p-3 text-center text-sm text-emerald-300">
                  <CheckCircle2 className="h-4 w-4" /> WhatsApp opened! Just tap “Send” to complete your order.
                </p>
              ) : (
                <p className="mt-4 text-center text-xs text-slate-500">
                  Your order details will open in WhatsApp, ready to send to {WHATSAPP_DISPLAY}.
                </p>
              )}
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
