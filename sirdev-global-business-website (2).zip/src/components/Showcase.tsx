import { useEffect, useMemo, useState } from "react";
import { ArrowUpRight, Check, Clock, X, Eye } from "lucide-react";
import { cn } from "../utils/cn";
import { websiteTypes, waLink, type Category, type WebsiteType } from "../data";
import { Reveal, SectionHeading, WhatsAppIcon } from "./ui";

const filters: ("All" | Category)[] = ["All", "Business", "Commerce", "Personal", "Community", "Apps"];

export default function Showcase({ onOrder }: { onOrder: (id: string) => void }) {
  const [active, setActive] = useState<(typeof filters)[number]>("All");
  const [selected, setSelected] = useState<WebsiteType | null>(null);

  const list = useMemo(
    () => (active === "All" ? websiteTypes : websiteTypes.filter((w) => w.category === active)),
    [active]
  );

  useEffect(() => {
    if (!selected) return;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setSelected(null);
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [selected]);

  return (
    <section id="websites" className="relative py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="What we build"
          title={
            <>
              Any kind of website, <span className="text-gradient">built for you</span>
            </>
          }
          subtitle="Browse the types of websites SIRDEV GLOBAL creates. Tap any card to see features and place your order instantly."
        />

        {/* Filters */}
        <div className="-mx-4 mb-10 overflow-x-auto px-4 sm:mx-0 sm:px-0">
          <div className="mx-auto flex w-max gap-2 rounded-2xl border border-white/10 bg-white/[0.03] p-1.5">
            {filters.map((f) => (
              <button
                key={f}
                onClick={() => setActive(f)}
                className={cn(
                  "whitespace-nowrap rounded-xl px-4 py-2 text-sm font-medium transition sm:px-5",
                  active === f
                    ? "bg-gradient-to-r from-emerald-400 to-teal-500 text-ink shadow-lg shadow-emerald-500/20"
                    : "text-slate-400 hover:text-white"
                )}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        {/* Grid */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((w, i) => (
            <Reveal key={w.id} delay={(i % 3) * 80}>
              <article className="group flex h-full flex-col overflow-hidden rounded-2xl border border-white/10 bg-panel transition duration-300 hover:-translate-y-1 hover:border-emerald-400/40 hover:shadow-2xl hover:shadow-emerald-500/10">
                <button
                  onClick={() => setSelected(w)}
                  className="relative block aspect-[16/10] overflow-hidden text-left"
                  aria-label={`View ${w.title} details`}
                >
                  {/* Browser bar */}
                  <div className="absolute inset-x-0 top-0 z-10 flex items-center gap-1.5 bg-slate-950/70 px-3 py-2 backdrop-blur">
                    <span className="h-2 w-2 rounded-full bg-red-400" />
                    <span className="h-2 w-2 rounded-full bg-yellow-400" />
                    <span className="h-2 w-2 rounded-full bg-green-400" />
                  </div>
                  <img
                    src={w.image}
                    alt={w.title}
                    loading="lazy"
                    className="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-panel via-panel/20 to-transparent" />
                  <span
                    className={cn(
                      "absolute bottom-3 left-4 rounded-full bg-gradient-to-r px-3 py-1 text-xs font-semibold text-ink",
                      w.accent
                    )}
                  >
                    {w.category}
                  </span>
                  <span className="absolute right-3 bottom-3 flex items-center gap-1 rounded-full bg-black/50 px-3 py-1 text-xs text-white opacity-0 backdrop-blur transition group-hover:opacity-100">
                    <Eye className="h-3.5 w-3.5" /> Details
                  </span>
                </button>

                <div className="flex flex-1 flex-col p-5 sm:p-6">
                  <h3 className="font-display text-xl font-bold text-white">{w.title}</h3>
                  <p className="mt-1 text-sm font-medium text-emerald-300">{w.tagline}</p>
                  <p className="mt-3 line-clamp-3 text-sm text-slate-400">{w.description}</p>

                  <div className="mt-5 flex items-end justify-between border-t border-white/5 pt-5">
                    <div>
                      <p className="text-[11px] uppercase tracking-wider text-slate-500">From</p>
                      <p className="font-display text-lg font-bold text-white">{w.price}</p>
                    </div>
                    <p className="flex items-center gap-1 text-xs text-slate-400">
                      <Clock className="h-3.5 w-3.5" /> {w.delivery}
                    </p>
                  </div>

                  <div className="mt-5 grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setSelected(w)}
                      className="rounded-xl border border-white/10 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-white/5"
                    >
                      View More
                    </button>
                    <button
                      onClick={() => onOrder(w.id)}
                      className="flex items-center justify-center gap-1 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-500 px-4 py-2.5 text-sm font-semibold text-ink transition hover:brightness-110"
                    >
                      Order <ArrowUpRight className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-12 text-center">
          <p className="text-slate-400">
            Don't see what you need?{" "}
            <a
              href={waLink("Hello SIRDEV GLOBAL, I need a custom website. Here are my requirements: ")}
              target="_blank"
              rel="noopener noreferrer"
              className="font-semibold text-emerald-400 underline-offset-4 hover:underline"
            >
              Tell us about your custom idea →
            </a>
          </p>
        </Reveal>
      </div>

      {/* Modal */}
      {selected && (
        <div
          className="fixed inset-0 z-[60] flex items-end justify-center bg-black/70 backdrop-blur-sm sm:items-center sm:p-6"
          onClick={() => setSelected(null)}
        >
          <div
            className="relative max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-t-3xl border border-white/10 bg-panel shadow-2xl sm:rounded-3xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setSelected(null)}
              className="absolute right-4 top-4 z-10 grid h-10 w-10 place-items-center rounded-full bg-black/60 text-white backdrop-blur hover:bg-black/80"
              aria-label="Close"
            >
              <X className="h-5 w-5" />
            </button>
            <div className="relative aspect-[16/8]">
              <img src={selected.image} alt={selected.title} className="h-full w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-panel to-transparent" />
            </div>
            <div className="-mt-12 relative p-6 sm:p-8">
              <span
                className={cn(
                  "rounded-full bg-gradient-to-r px-3 py-1 text-xs font-semibold text-ink",
                  selected.accent
                )}
              >
                {selected.category}
              </span>
              <h3 className="mt-4 font-display text-2xl font-bold text-white sm:text-3xl">{selected.title}</h3>
              <p className="mt-1 font-medium text-emerald-300">{selected.tagline}</p>
              <p className="mt-4 text-slate-300">{selected.description}</p>

              <h4 className="mt-6 text-sm font-semibold uppercase tracking-wider text-slate-500">Key features</h4>
              <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                {[...selected.features, "Mobile & laptop responsive", "WhatsApp chat integration"].map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm text-slate-300">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" /> {f}
                  </li>
                ))}
              </ul>

              <div className="mt-6 grid grid-cols-2 gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
                <div>
                  <p className="text-xs text-slate-500">Starting price</p>
                  <p className="font-display text-xl font-bold text-white">{selected.price}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-500">Delivery time</p>
                  <p className="font-display text-xl font-bold text-white">{selected.delivery}</p>
                </div>
              </div>

              <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                <button
                  onClick={() => {
                    const id = selected.id;
                    setSelected(null);
                    onOrder(id);
                  }}
                  className="flex-1 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-500 px-6 py-3.5 font-semibold text-ink transition hover:brightness-110"
                >
                  Fill Order Form
                </button>
                <a
                  href={waLink(
                    `Hello SIRDEV GLOBAL 👋\n\nI'm interested in a *${selected.title}* website (from ${selected.price}). Please send me more details.`
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-[#25D366] px-6 py-3.5 font-semibold text-white transition hover:brightness-110"
                >
                  <WhatsAppIcon className="h-5 w-5" /> Order via WhatsApp
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
